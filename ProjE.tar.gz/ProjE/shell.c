int strCompare(char*, char*);

void main()
{

	char line[11];
	char* type = "type\0";
	char* exec = "exec\0";
	char* create ="create\0";
	char* copy = "copy\0";
	char* dir = "dir\0";
	char* del = "del\0";
	char* kill = "kill\0";
	char buffer[13312];
	int sectorsRead = 0; 

	int x = 1 ;
	enableInterrupts();
	while (x == 1)
	{
		syscall(0, "\n\rSHELL> ");

		syscall(1, line);

		if (strCompare(line, type, 4) == 1)
		{
			syscall(3, line+5, buffer, &sectorsRead);
			if (sectorsRead == 0)
			{
				syscall(0, "File Not Found. \r\n");
			}
			else
			{
				syscall(0, buffer);
				syscall(0, "\r\n");
				syscall(5);
			}
		}
		else if(strCompare(line, del,3)==1)
		{
			syscall(7, line+4);
		}

		else if (strCompare(line, dir, 3) == 1)
		{
			syscall(2, buffer, 2);
			syscall(20, buffer);
			
		}

		else if (strCompare(line, exec, 4) == 1)
		{
			syscall(4, line+5);
			*(line + 5) = '\0';
			//syscall(5);
		}
		else if (strCompare(line,copy,4)==1)
		{
			char buffer[512];
			int sectorsRead;
			syscall(3, line+5, buffer, &sectorsRead);
			syscall(8, buffer, line+12, 2);
		}

		else if(strCompare(line,kill,4) ==1){

			syscall(9,line[5]);
		}

			
		
//		else if(strCompare(line,create,6)==1)
//		{
//			syscall(1,line);
//			while(line != '\0')
//			{
			
			

//			}
//		}
		else
		{
			syscall(0, "Bad command \r\n");
		}
		
		//syscall(0, line);

		//syscall(0, "FATAL! :( \r\n");
	}

}
int strCompare(char* line, char* command, int commandLength) //returns 0 if not same, 1 if same
{
	int i;
	for(i = 0; i<commandLength; i++)
	{
		if(line[i] != command[i])
		{
			//interrupt(0x21, 0, "File name NOT found in dir\r\n", 0, 0);
			return 0;
		}
		if (line[i] == '\0')
		{
			//interrupt(0x21, 0, "File name found in dir\r\n", 0, 0);
			return 1;
		}
	}

	//interrupt(0x21, 0, "File name found in dir at end of loop returning\r\n", 0, 0);
	return 1;
}
